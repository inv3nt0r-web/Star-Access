import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import Navigation from '@/components/ui/Navigation'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Star Access - Premium Marketing & Content Creation',
  description: 'Professionelles Marketing, Content Creation und Social Media Management für Ihr Business',
  keywords: 'Marketing, Social Media, TikTok, Instagram, Content Creation, Star Access',
  openGraph: {
    title: 'Star Access - Premium Marketing & Content Creation',
    description: 'Professionelles Marketing, Content Creation und Social Media Management',
    url: 'https://www.staracces.com',
    siteName: 'Star Access',
    images: [
      {
        url: '/images/og-image.jpg',
        width: 1200,
        height: 630,
      },
    ],
    locale: 'de_DE',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Star Access',
    description: 'Premium Marketing & Content Creation',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="de">
      <body className={inter.className}>
        <Navigation />
        <main className="min-h-screen">
          {children}
        </main>
        <footer className="bg-black/50 backdrop-blur-sm border-t border-star-purple/20 py-8 mt-20">
          <div className="container mx-auto px-4 text-center">
            <p className="text-gray-400">© 2024 Star Access. Alle Rechte vorbehalten.</p>
            <div className="flex justify-center gap-6 mt-4">
              <a href="https://www.tiktok.com/@staraccess" target="_blank" rel="noopener noreferrer" 
                 className="text-gray-400 hover:text-star-pink transition-colors">
                TikTok
              </a>
              <a href="https://www.instagram.com/staraccess" target="_blank" rel="noopener noreferrer"
                 className="text-gray-400 hover:text-star-purple transition-colors">
                Instagram
              </a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}
