'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { Sparkles, Zap, TrendingUp, Video, Instagram, MessageSquare, Star, ArrowRight } from 'lucide-react'

export default function Home() {
  const fadeInUp = {
    initial: { opacity: 0, y: 60 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  }

  const services = [
    {
      icon: <Video className="w-8 h-8" />,
      title: 'Content Creation',
      description: 'Professionelle Video & Foto Produktion für Social Media',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Social Media Marketing',
      description: 'TikTok & Instagram Wachstum mit bewährten Strategien',
      color: 'from-pink-500 to-orange-500'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Automatisierung',
      description: 'KI-gestützte Tools für effizientes Content Management',
      color: 'from-blue-500 to-purple-500'
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: 'Branding',
      description: 'Aufbau Ihrer einzigartigen Marken-Identität',
      color: 'from-gold-500 to-yellow-500'
    }
  ]

  const stats = [
    { value: '500K+', label: 'Follower generiert' },
    { value: '50M+', label: 'Views erreicht' },
    { value: '100+', label: 'Erfolgreiche Kampagnen' },
    { value: '98%', label: 'Kundenzufriedenheit' }
  ]

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 px-4">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-96 h-96 bg-star-purple/30 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-star-pink/30 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-star-blue/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
        </div>

        <div className="container mx-auto text-center relative z-10">
          <motion.div {...fadeInUp}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full mb-8 border border-white/20">
              <Star className="w-4 h-4 text-star-gold" fill="currentColor" />
              <span className="text-sm">Ihr Partner für digitalen Erfolg</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Bringen Sie Ihre Marke
              <br />
              <span className="text-gradient">auf die nächste Stufe</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto">
              Von Content Creation bis Marketing-Automatisierung - 
              Wir machen Ihr Business zum Star auf TikTok & Instagram
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/kontakt" 
                className="px-8 py-4 bg-gradient-star rounded-full font-semibold text-lg glow hover:scale-105 transition-transform flex items-center gap-2 group">
                Jetzt starten
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link href="/videos" 
                className="px-8 py-4 bg-white/10 backdrop-blur-sm rounded-full font-semibold text-lg border border-white/20 hover:bg-white/20 transition-all">
                Unsere Arbeiten ansehen
              </Link>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-24 max-w-4xl mx-auto"
          >
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-gradient mb-2">{stat.value}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/60 rounded-full mt-2 animate-bounce"></div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 relative">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Unsere <span className="text-gradient">Services</span>
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Alles was Sie brauchen für erfolgreiches Social Media Marketing
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="p-6 bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 card-hover"
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-4`}>
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                <p className="text-gray-400">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 relative">
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="bg-gradient-star rounded-3xl p-12 text-center glow"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Bereit durchzustarten?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Kontaktieren Sie uns für ein kostenloses Erstgespräch
            </p>
            <Link href="/kontakt"
              className="inline-block px-8 py-4 bg-white text-star-purple rounded-full font-semibold text-lg hover:scale-105 transition-transform">
              Kostenlos beraten lassen
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h3 className="text-2xl font-bold mb-8">Folgen Sie uns auf Social Media</h3>
          <div className="flex justify-center gap-6">
            <a href="https://www.tiktok.com/@staraccess" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 rounded-full transition-all border border-white/10 hover:border-star-pink/50">
              <MessageSquare className="w-5 h-5 text-star-pink" />
              <span>@staraccess</span>
            </a>
            <a href="https://www.instagram.com/staraccess" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 rounded-full transition-all border border-white/10 hover:border-star-purple/50">
              <Instagram className="w-5 h-5 text-star-purple" />
              <span>@staraccess</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
