'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { Video, TrendingUp, Zap, Sparkles, Target, Rocket, Users, BarChart, ArrowRight, CheckCircle } from 'lucide-react'

export default function ServicesPage() {
  const services = [
    {
      icon: <Video className="w-12 h-12" />,
      title: 'Content Creation',
      description: 'Professionelle Video- und Fotoproduktion für alle Social Media Plattformen',
      features: [
        'TikTok Videos & Reels',
        'Instagram Content',
        'YouTube Shorts',
        'Professionelle Videobearbeitung',
        'Thumbnails & Graphics',
        'Script-Writing'
      ],
      color: 'from-purple-500 to-pink-500',
      price: 'ab 499€'
    },
    {
      icon: <TrendingUp className="w-12 h-12" />,
      title: 'Social Media Marketing',
      description: 'Strategisches Wachstum auf TikTok, Instagram und anderen Plattformen',
      features: [
        'Follower-Wachstum',
        'Engagement-Optimierung',
        'Hashtag-Strategie',
        'Trend-Analyse',
        'Community Management',
        'Influencer Kooperationen'
      ],
      color: 'from-pink-500 to-orange-500',
      price: 'ab 799€'
    },
    {
      icon: <Zap className="w-12 h-12" />,
      title: 'Marketing Automatisierung',
      description: 'KI-gestützte Tools für effizientes Content Management und Posting',
      features: [
        'Automatisches Posting',
        'Content-Scheduler',
        'AI Caption Generator',
        'Performance Tracking',
        'Multi-Platform Management',
        'Analytics Dashboard'
      ],
      color: 'from-blue-500 to-purple-500',
      price: 'ab 399€'
    },
    {
      icon: <Sparkles className="w-12 h-12" />,
      title: 'Branding & Strategie',
      description: 'Entwicklung Ihrer einzigartigen Marken-Identität und Content-Strategie',
      features: [
        'Brand Identity Design',
        'Content-Strategie',
        'Competitor Analysis',
        'Target Audience Research',
        'Brand Guidelines',
        'Consulting Sessions'
      ],
      color: 'from-gold-500 to-yellow-500',
      price: 'ab 999€'
    }
  ]

  const process = [
    {
      icon: <Target className="w-8 h-8" />,
      title: 'Analyse & Strategie',
      description: 'Wir analysieren Ihre Zielgruppe, Konkurrenz und entwickeln eine maßgeschneiderte Strategie'
    },
    {
      icon: <Rocket className="w-8 h-8" />,
      title: 'Content Creation',
      description: 'Produktion von hochwertigem, ansprechendem Content der Ihre Zielgruppe begeistert'
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Community Building',
      description: 'Aufbau einer engagierten Community durch konsistente Interaktion und Mehrwert'
    },
    {
      icon: <BarChart className="w-8 h-8" />,
      title: 'Optimierung',
      description: 'Kontinuierliche Analyse und Optimierung basierend auf Performance-Daten'
    }
  ]

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Unsere <span className="text-gradient">Services</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Von Content Creation bis zur kompletten Marketing-Automatisierung - 
            Wir bieten alle Services, die Sie für erfolgreiche Social Media Präsenz brauchen
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-20">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 overflow-hidden card-hover"
            >
              <div className={`h-2 bg-gradient-to-r ${service.color}`}></div>
              <div className="p-8">
                <div className={`w-20 h-20 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-6`}>
                  {service.icon}
                </div>
                
                <h3 className="text-2xl font-bold mb-3">{service.title}</h3>
                <p className="text-gray-400 mb-6">{service.description}</p>

                <div className="space-y-3 mb-6">
                  {service.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-6 border-t border-white/10">
                  <div>
                    <div className="text-sm text-gray-400 mb-1">Startpreis</div>
                    <div className="text-2xl font-bold text-gradient">{service.price}</div>
                  </div>
                  <Link 
                    href="/kontakt"
                    className="px-6 py-3 bg-gradient-star rounded-lg font-semibold hover:scale-105 transition-transform flex items-center gap-2"
                  >
                    Anfragen
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Process Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">
              Unser <span className="text-gradient">Prozess</span>
            </h2>
            <p className="text-xl text-gray-400">
              So bringen wir Ihre Marke zum Erfolg
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {process.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="relative"
              >
                <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 h-full">
                  <div className="absolute -top-4 left-6 w-8 h-8 bg-gradient-star rounded-full flex items-center justify-center font-bold glow">
                    {index + 1}
                  </div>
                  <div className="w-16 h-16 bg-gradient-star rounded-xl flex items-center justify-center mb-4 mt-4">
                    {step.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                  <p className="text-sm text-gray-400">{step.description}</p>
                </div>
                
                {index < process.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gradient-to-r from-star-purple to-star-pink"></div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-star rounded-3xl p-12 text-center glow"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Bereit für den nächsten Schritt?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Lassen Sie uns in einem kostenlosen Beratungsgespräch die perfekte Strategie 
            für Ihr Business entwickeln
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/kontakt"
              className="inline-block px-8 py-4 bg-white text-star-purple rounded-full font-semibold text-lg hover:scale-105 transition-transform">
              Kostenlos beraten lassen
            </Link>
            <Link href="/videos"
              className="inline-block px-8 py-4 bg-white/20 backdrop-blur-sm rounded-full font-semibold text-lg border-2 border-white hover:bg-white/30 transition-all">
              Portfolio ansehen
            </Link>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          <div className="text-center p-6 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-4xl font-bold text-gradient mb-2">500K+</div>
            <div className="text-sm text-gray-400">Follower aufgebaut</div>
          </div>
          <div className="text-center p-6 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-4xl font-bold text-gradient mb-2">50M+</div>
            <div className="text-sm text-gray-400">Views generiert</div>
          </div>
          <div className="text-center p-6 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-4xl font-bold text-gradient mb-2">100+</div>
            <div className="text-sm text-gray-400">Erfolgreiche Projekte</div>
          </div>
          <div className="text-center p-6 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-4xl font-bold text-gradient mb-2">98%</div>
            <div className="text-sm text-gray-400">Zufriedene Kunden</div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
