'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Play, Eye, Heart, Share2, TrendingUp, Filter } from 'lucide-react'

export default function VideosPage() {
  const [selectedCategory, setSelectedCategory] = useState('all')

  const categories = [
    { id: 'all', label: 'Alle Videos' },
    { id: 'tiktok', label: 'TikTok' },
    { id: 'instagram', label: 'Instagram' },
    { id: 'commercial', label: 'Werbung' },
    { id: 'tutorials', label: 'Tutorials' }
  ]

  const videos = [
    {
      id: 1,
      title: 'Viral TikTok Kampagne',
      category: 'tiktok',
      thumbnail: '/videos/thumb1.jpg',
      views: '2.5M',
      likes: '450K',
      platform: 'TikTok',
      description: 'Eine virale Kampagne die in 3 Tagen 2.5M Views erreicht hat'
    },
    {
      id: 2,
      title: 'Instagram Reel - Produktlaunch',
      category: 'instagram',
      thumbnail: '/videos/thumb2.jpg',
      views: '890K',
      likes: '125K',
      platform: 'Instagram',
      description: 'Erfolgreicher Produktlaunch mit hoher Conversion Rate'
    },
    {
      id: 3,
      title: 'Brand Storytelling',
      category: 'commercial',
      thumbnail: '/videos/thumb3.jpg',
      views: '1.2M',
      likes: '200K',
      platform: 'TikTok',
      description: 'Emotionale Brand Story die authentisch überzeugt'
    },
    {
      id: 4,
      title: 'Tutorial: Content Creation Hacks',
      category: 'tutorials',
      thumbnail: '/videos/thumb4.jpg',
      views: '650K',
      likes: '98K',
      platform: 'Instagram',
      description: 'Die besten Tipps für viralen Content'
    },
    {
      id: 5,
      title: 'Behind the Scenes',
      category: 'tiktok',
      thumbnail: '/videos/thumb5.jpg',
      views: '1.8M',
      likes: '320K',
      platform: 'TikTok',
      description: 'Einblicke in unseren kreativen Prozess'
    },
    {
      id: 6,
      title: 'Product Demo Reel',
      category: 'instagram',
      thumbnail: '/videos/thumb6.jpg',
      views: '750K',
      likes: '142K',
      platform: 'Instagram',
      description: 'Kreative Produktpräsentation die konvertiert'
    }
  ]

  const filteredVideos = selectedCategory === 'all' 
    ? videos 
    : videos.filter(v => v.category === selectedCategory)

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Unsere <span className="text-gradient">Portfolio</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-8">
            Erfolgreiche Kampagnen und virale Inhalte die Millionen Menschen erreicht haben
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <div className="text-3xl font-bold text-gradient mb-1">50M+</div>
              <div className="text-sm text-gray-400">Total Views</div>
            </div>
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <div className="text-3xl font-bold text-gradient mb-1">8M+</div>
              <div className="text-sm text-gray-400">Total Likes</div>
            </div>
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <div className="text-3xl font-bold text-gradient mb-1">500K+</div>
              <div className="text-sm text-gray-400">Followers</div>
            </div>
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <div className="text-3xl font-bold text-gradient mb-1">100+</div>
              <div className="text-sm text-gray-400">Projekte</div>
            </div>
          </div>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="flex flex-wrap gap-3 justify-center mb-12"
        >
          <div className="flex items-center gap-2 text-gray-400 mr-4">
            <Filter className="w-5 h-5" />
            <span className="text-sm">Filter:</span>
          </div>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                selectedCategory === cat.id
                  ? 'bg-gradient-star glow'
                  : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </motion.div>

        {/* Video Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl bg-white/5 border border-white/10 card-hover">
                {/* Thumbnail */}
                <div className="relative aspect-[9/16] bg-gradient-to-br from-star-purple/20 to-star-pink/20 flex items-center justify-center">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Play className="w-8 h-8 ml-1" fill="currentColor" />
                    </div>
                  </div>
                  
                  {/* Platform Badge */}
                  <div className="absolute top-3 right-3 px-3 py-1 bg-black/60 backdrop-blur-sm rounded-full text-xs font-medium">
                    {video.platform}
                  </div>

                  {/* Stats Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        <span>{video.views}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Heart className="w-4 h-4 text-red-400" />
                        <span>{video.likes}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Info */}
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2 group-hover:text-gradient transition-colors">
                    {video.title}
                  </h3>
                  <p className="text-sm text-gray-400 line-clamp-2">
                    {video.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <div className="bg-gradient-star rounded-3xl p-12 glow max-w-3xl mx-auto">
            <TrendingUp className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Bereit für Ihren viralen Durchbruch?
            </h2>
            <p className="text-lg mb-8 opacity-90">
              Lassen Sie uns gemeinsam Content kreieren, der Millionen erreicht
            </p>
            <a
              href="/kontakt"
              className="inline-block px-8 py-4 bg-white text-star-purple rounded-full font-semibold hover:scale-105 transition-transform"
            >
              Projekt starten
            </a>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
