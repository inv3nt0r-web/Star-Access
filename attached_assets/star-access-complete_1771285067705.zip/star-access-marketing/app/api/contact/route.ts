import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, phone, service, message } = body

    // Validierung
    if (!name || !email || !service || !message) {
      return NextResponse.json(
        { error: 'Bitte füllen Sie alle Pflichtfelder aus' },
        { status: 400 }
      )
    }

    // Hier würdest du die Email versenden oder in einer Datenbank speichern
    // Beispiel mit einem Email-Service wie SendGrid, Resend, etc.
    
    console.log('Neue Kontaktanfrage:', { name, email, phone, service, message })

    // Simuliere erfolgreiche Verarbeitung
    // In Produktion: Sende Email oder speichere in DB
    
    /*
    // Beispiel mit Resend:
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: 'kontakt@staracces.com',
        to: 'kontakt@staracces.com',
        subject: `Neue Anfrage: ${service}`,
        html: `
          <h2>Neue Kontaktanfrage</h2>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Telefon:</strong> ${phone || 'Nicht angegeben'}</p>
          <p><strong>Service:</strong> ${service}</p>
          <p><strong>Nachricht:</strong></p>
          <p>${message}</p>
        `
      })
    })
    */

    return NextResponse.json({
      success: true,
      message: 'Nachricht erfolgreich gesendet!'
    })
  } catch (error) {
    console.error('Fehler beim Verarbeiten der Kontaktanfrage:', error)
    return NextResponse.json(
      { error: 'Serverfehler. Bitte versuchen Sie es später erneut.' },
      { status: 500 }
    )
  }
}
