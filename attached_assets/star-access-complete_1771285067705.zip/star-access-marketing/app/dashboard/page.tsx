'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Calendar, Sparkles, TrendingUp, Send, Copy, RefreshCw, Instagram, MessageSquare, Video, Image as ImageIcon, Clock, CheckCircle } from 'lucide-react'

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('scheduler')
  const [aiPrompt, setAiPrompt] = useState('')
  const [generatedContent, setGeneratedContent] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)

  // Content Scheduler State
  const [scheduledPosts, setScheduledPosts] = useState([
    {
      id: 1,
      platform: 'tiktok',
      content: 'Neues Tutorial über Content Creation! 🎥✨',
      scheduledFor: '2024-02-20T14:00',
      status: 'scheduled',
      mediaType: 'video'
    },
    {
      id: 2,
      platform: 'instagram',
      content: 'Behind the scenes unserer neuesten Kampagne 📸',
      scheduledFor: '2024-02-21T18:00',
      status: 'scheduled',
      mediaType: 'image'
    }
  ])

  const [newPost, setNewPost] = useState({
    platform: 'tiktok',
    content: '',
    scheduledFor: '',
    mediaType: 'video'
  })

  const tabs = [
    { id: 'scheduler', label: 'Content Scheduler', icon: <Calendar className="w-5 h-5" /> },
    { id: 'ai', label: 'AI Prompts', icon: <Sparkles className="w-5 h-5" /> },
    { id: 'analytics', label: 'Analytics', icon: <TrendingUp className="w-5 h-5" /> }
  ]

  const promptTemplates = [
    {
      title: 'Viraler TikTok Hook',
      prompt: 'Erstelle einen aufmerksamkeitsstarken Hook für ein TikTok-Video über [THEMA]. Der Hook sollte in den ersten 3 Sekunden fesseln und Neugier wecken.'
    },
    {
      title: 'Instagram Caption',
      prompt: 'Schreibe eine ansprechende Instagram Caption für einen Post über [THEMA]. Inkludiere relevante Hashtags und einen Call-to-Action.'
    },
    {
      title: 'Content-Ideen',
      prompt: 'Generiere 10 virale Content-Ideen für [PLATTFORM] im Bereich [NISCHE]. Die Ideen sollten trendig und einfach umsetzbar sein.'
    },
    {
      title: 'Hashtag-Strategie',
      prompt: 'Erstelle eine optimale Hashtag-Strategie für [THEMA]. Mische hochfrequentierte und Nischen-Hashtags für maximale Reichweite.'
    }
  ]

  const generateAIContent = async () => {
    setIsGenerating(true)
    // Simuliere AI Generation (hier würdest du später deine AI API anbinden)
    setTimeout(() => {
      setGeneratedContent(`🎯 Generierter Content basierend auf deinem Prompt:

Hook: "Stoppt alles! Das musst du über ${aiPrompt} wissen! 🚨"

Hauptinhalt:
1. Der überraschende Fakt, den niemand kennt
2. Die 3 größten Fehler, die du vermeiden solltest
3. Mein Geheimtipp für sofortige Ergebnisse

Call-to-Action: "Speichere diesen Post für später und folge für mehr!" 

Hashtags: #${aiPrompt.replace(/\s+/g, '')} #viral #tutorial #tipp #motivation #erfolg #2024

💡 Beste Posting-Zeit: 18:00-20:00 Uhr
📊 Erwartete Reichweite: 10K-50K Views`)
      setIsGenerating(false)
    }, 2000)
  }

  const schedulePost = () => {
    if (newPost.content && newPost.scheduledFor) {
      setScheduledPosts([...scheduledPosts, {
        id: Date.now(),
        ...newPost,
        status: 'scheduled'
      }])
      setNewPost({ platform: 'tiktok', content: '', scheduledFor: '', mediaType: 'video' })
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-4">
            Marketing <span className="text-gradient">Dashboard</span>
          </h1>
          <p className="text-xl text-gray-400">
            Verwalte deine Social Media Präsenz und automatisiere dein Content Marketing
          </p>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-star glow'
                  : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Scheduler Tab */}
        {activeTab === 'scheduler' && (
          <div className="grid lg:grid-cols-2 gap-6">
            {/* New Post Form */}
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
            >
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Send className="w-6 h-6" />
                Neuen Post planen
              </h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Plattform</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setNewPost({...newPost, platform: 'tiktok'})}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        newPost.platform === 'tiktok'
                          ? 'border-star-pink bg-star-pink/20'
                          : 'border-white/10 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <MessageSquare className="w-8 h-8 mx-auto mb-2" />
                      <div className="text-sm font-medium">TikTok</div>
                    </button>
                    <button
                      onClick={() => setNewPost({...newPost, platform: 'instagram'})}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        newPost.platform === 'instagram'
                          ? 'border-star-purple bg-star-purple/20'
                          : 'border-white/10 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <Instagram className="w-8 h-8 mx-auto mb-2" />
                      <div className="text-sm font-medium">Instagram</div>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Media Type</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setNewPost({...newPost, mediaType: 'video'})}
                      className={`p-3 rounded-lg flex items-center gap-2 justify-center transition-all ${
                        newPost.mediaType === 'video'
                          ? 'bg-star-blue/20 border-2 border-star-blue'
                          : 'bg-white/5 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <Video className="w-5 h-5" />
                      Video
                    </button>
                    <button
                      onClick={() => setNewPost({...newPost, mediaType: 'image'})}
                      className={`p-3 rounded-lg flex items-center gap-2 justify-center transition-all ${
                        newPost.mediaType === 'image'
                          ? 'bg-star-gold/20 border-2 border-star-gold'
                          : 'bg-white/5 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <ImageIcon className="w-5 h-5" />
                      Bild
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Content / Caption</label>
                  <textarea
                    rows={4}
                    value={newPost.content}
                    onChange={(e) => setNewPost({...newPost, content: e.target.value})}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:border-star-purple transition-colors resize-none"
                    placeholder="Schreibe deine Caption..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Geplant für</label>
                  <input
                    type="datetime-local"
                    value={newPost.scheduledFor}
                    onChange={(e) => setNewPost({...newPost, scheduledFor: e.target.value})}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:border-star-purple transition-colors"
                  />
                </div>

                <button
                  onClick={schedulePost}
                  className="w-full px-6 py-3 bg-gradient-star rounded-lg font-semibold hover:scale-105 transition-transform flex items-center justify-center gap-2 glow"
                >
                  <Calendar className="w-5 h-5" />
                  Post einplanen
                </button>
              </div>
            </motion.div>

            {/* Scheduled Posts */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
            >
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Clock className="w-6 h-6" />
                Geplante Posts ({scheduledPosts.length})
              </h2>

              <div className="space-y-4">
                {scheduledPosts.map((post) => (
                  <div key={post.id} className="p-4 bg-white/5 rounded-lg border border-white/10">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {post.platform === 'tiktok' ? (
                          <MessageSquare className="w-5 h-5 text-star-pink" />
                        ) : (
                          <Instagram className="w-5 h-5 text-star-purple" />
                        )}
                        <span className="font-medium capitalize">{post.platform}</span>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-green-400">
                        <CheckCircle className="w-4 h-4" />
                        Geplant
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-300 mb-3">{post.content}</p>
                    
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {new Date(post.scheduledFor).toLocaleString('de-DE')}
                      </div>
                      <div className="flex items-center gap-1">
                        {post.mediaType === 'video' ? (
                          <Video className="w-4 h-4" />
                        ) : (
                          <ImageIcon className="w-4 h-4" />
                        )}
                        {post.mediaType}
                      </div>
                    </div>
                  </div>
                ))}

                {scheduledPosts.length === 0 && (
                  <div className="text-center py-12 text-gray-400">
                    <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>Noch keine Posts geplant</p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {/* AI Prompts Tab */}
        {activeTab === 'ai' && (
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Prompt Generator */}
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
            >
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Sparkles className="w-6 h-6" />
                AI Content Generator
              </h2>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Dein Thema / Nische</label>
                  <input
                    type="text"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:border-star-purple transition-colors"
                    placeholder="z.B. Social Media Marketing"
                  />
                </div>

                <button
                  onClick={generateAIContent}
                  disabled={!aiPrompt || isGenerating}
                  className="w-full px-6 py-3 bg-gradient-star rounded-lg font-semibold hover:scale-105 transition-transform flex items-center justify-center gap-2 glow disabled:opacity-50 disabled:hover:scale-100"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      Generiere...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      Content generieren
                    </>
                  )}
                </button>
              </div>

              {generatedContent && (
                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-green-400">✓ Generiert</span>
                    <button
                      onClick={() => copyToClipboard(generatedContent)}
                      className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                  <pre className="text-sm whitespace-pre-wrap text-gray-300">{generatedContent}</pre>
                </div>
              )}

              <div className="mt-6">
                <h3 className="font-semibold mb-3">📌 Quick Templates</h3>
                <div className="space-y-2">
                  {promptTemplates.map((template, index) => (
                    <button
                      key={index}
                      onClick={() => setAiPrompt(template.prompt)}
                      className="w-full text-left p-3 bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 transition-colors"
                    >
                      <div className="font-medium text-sm mb-1">{template.title}</div>
                      <div className="text-xs text-gray-400 line-clamp-1">{template.prompt}</div>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Tips & Best Practices */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <div className="bg-gradient-star rounded-2xl p-6 glow">
                <h3 className="text-xl font-bold mb-4">🚀 Pro-Tipps für viralen Content</h3>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="text-lg">•</span>
                    <span>Die ersten 3 Sekunden entscheiden über Erfolg oder Misserfolg</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-lg">•</span>
                    <span>Nutze Trending Sounds und Hashtags für maximale Reichweite</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-lg">•</span>
                    <span>Poste konsistent - mindestens 1x täglich</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-lg">•</span>
                    <span>Analysiere deine Performance und optimiere kontinuierlich</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
                <h3 className="text-xl font-bold mb-4">📊 Beste Posting-Zeiten</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="flex items-center gap-2">
                      <MessageSquare className="w-5 h-5 text-star-pink" />
                      TikTok
                    </span>
                    <span className="text-sm text-gray-400">18:00 - 21:00</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="flex items-center gap-2">
                      <Instagram className="w-5 h-5 text-star-purple" />
                      Instagram
                    </span>
                    <span className="text-sm text-gray-400">11:00 - 13:00, 19:00 - 21:00</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-gray-400">Total Reach</span>
                <TrendingUp className="w-5 h-5 text-green-400" />
              </div>
              <div className="text-3xl font-bold text-gradient mb-2">2.8M</div>
              <div className="text-sm text-green-400">+24% vs. letzte Woche</div>
            </div>

            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-gray-400">Engagement</span>
                <TrendingUp className="w-5 h-5 text-blue-400" />
              </div>
              <div className="text-3xl font-bold text-gradient mb-2">8.2%</div>
              <div className="text-sm text-blue-400">+12% vs. letzte Woche</div>
            </div>

            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-gray-400">Follower</span>
                <TrendingUp className="w-5 h-5 text-purple-400" />
              </div>
              <div className="text-3xl font-bold text-gradient mb-2">45K</div>
              <div className="text-sm text-purple-400">+1.2K diese Woche</div>
            </div>

            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-gray-400">Posts</span>
                <Send className="w-5 h-5 text-pink-400" />
              </div>
              <div className="text-3xl font-bold text-gradient mb-2">28</div>
              <div className="text-sm text-pink-400">Diese Woche</div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
