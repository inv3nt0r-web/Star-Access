/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['staracces.com', 'www.staracces.com'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.cdninstagram.com',
      },
      {
        protocol: 'https',
        hostname: '**.tiktokcdn.com',
      },
    ],
  },
  env: {
    SITE_URL: 'https://www.staracces.com',
    SITE_NAME: 'Star Access',
  },
}

module.exports = nextConfig
