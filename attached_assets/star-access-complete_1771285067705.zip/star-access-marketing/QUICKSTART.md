# ⚡ QUICK START - Star Access Marketing Platform

## 🚀 In 5 Minuten live gehen!

### Option A: Lokale Installation

```bash
# 1. In Projekt-Ordner navigieren
cd star-access-marketing

# 2. Dependencies installieren
npm install

# 3. Development Server starten
npm run dev

# 4. Öffne Browser
http://localhost:3000
```

**Fertig! 🎉** Die Website läuft jetzt lokal.

---

### Option B: Replit Deployment (EMPFOHLEN)

#### Schritt 1: Projekt auf Replit hochladen

1. Gehe zu **[replit.com](https://replit.com)**
2. Klicke **"Create Repl"**
3. Wähle **"Import from Upload"**
4. Lade den kompletten `star-access-marketing` Ordner hoch

#### Schritt 2: Starten

Replit erkennt automatisch die Konfiguration und startet das Projekt!

```bash
# Falls nicht automatisch gestartet, klicke "Run" oder führe aus:
npm install && npm run dev
```

**Deine Website ist jetzt live!** 🌟

URL: `https://[dein-repl-name].replit.app`

#### Schritt 3: Domain verbinden (www.staracces.com)

1. In Replit: Klicke **"Deploy"** Tab
2. Wähle **"Custom Domain"**
3. Füge `www.staracces.com` hinzu
4. Kopiere die DNS-Einstellungen
5. Füge bei deinem Domain-Provider hinzu:

```
Type: CNAME
Name: www
Value: [deine-replit-url]
```

**Fertig!** Deine Website ist unter www.staracces.com erreichbar! 🎊

---

## 🎯 Die wichtigsten Seiten

Nach dem Start kannst du diese Seiten besuchen:

- **Homepage**: `/` - Hauptseite mit Hero & Features
- **Services**: `/services` - Alle Angebote
- **Videos**: `/videos` - Portfolio
- **Kontakt**: `/kontakt` - Kontaktformular
- **Dashboard**: `/dashboard` - Marketing-Automatisierung ⭐

---

## 🎨 Erste Schritte nach Installation

### 1. Branding anpassen

**Farben** in `tailwind.config.js`:
```javascript
colors: {
  'star': {
    purple: '#8B5CF6',  // Deine Hauptfarbe
    pink: '#EC4899',    // Deine Akzentfarbe
    blue: '#3B82F6',
    gold: '#F59E0B',
  }
}
```

### 2. Eigene Bilder hochladen

```bash
/public/images/  # Hier deine Bilder hinzufügen
/public/videos/  # Hier deine Videos hinzufügen
```

Nutze dann in deinen Components:
```typescript
import Image from 'next/image'
<Image src="/images/dein-bild.jpg" width={800} height={600} alt="Beschreibung" />
```

### 3. Texte anpassen

Alle Texte findest du in:
- `app/page.tsx` - Homepage
- `app/services/page.tsx` - Services
- `app/kontakt/page.tsx` - Kontakt
- `app/videos/page.tsx` - Videos
- `app/dashboard/page.tsx` - Dashboard

Einfach die Texte in den Dateien ändern!

---

## 🤖 Marketing Automatisierung aktivieren

### Quick Setup:

1. **Social Media verknüpfen**:
   - Gehe zu [TikTok Developers](https://developers.tiktok.com/)
   - Erstelle App & erhalte API Keys
   - Füge in Replit Secrets hinzu

2. **AI Content Generator**:
   - Erstelle Account bei [OpenAI](https://openai.com)
   - Erhalte API Key
   - Füge als Secret hinzu: `OPENAI_API_KEY`

3. **Email für Kontaktformular**:
   - Erstelle Account bei [Resend](https://resend.com)
   - Erhalte API Key
   - Füge als Secret hinzu: `RESEND_API_KEY`

**Alles im Detail in der README.md!**

---

## 🆘 Probleme?

### Website startet nicht?

```bash
# Lösche Abhängigkeiten und installiere neu
rm -rf node_modules
npm install
npm run dev
```

### Port 3000 belegt?

```bash
# Ändere Port
npm run dev -- -p 3001
```

### Styling funktioniert nicht?

```bash
# Stelle sicher dass Tailwind läuft
npm run dev
# Und öffne Browser im Inkognito-Modus
```

---

## 📞 Support

- **Email**: kontakt@staracces.com
- **TikTok**: [@staraccess](https://www.tiktok.com/@staraccess)
- **Instagram**: [@staraccess](https://www.instagram.com/staraccess)

---

## ✅ Checkliste nach Installation

- [ ] Website läuft lokal oder auf Replit
- [ ] Alle Seiten funktionieren
- [ ] Eigene Farben angepasst
- [ ] Eigene Bilder hochgeladen
- [ ] Texte personalisiert
- [ ] Domain verbunden
- [ ] Social Media APIs verknüpft (optional)
- [ ] Email-Service eingerichtet (optional)

---

## 🎉 Geschafft!

Du hast jetzt eine vollwertige Marketing-Website mit:
- ✅ Moderne, responsive Design
- ✅ Multi-Page Setup
- ✅ Marketing Dashboard
- ✅ Content Scheduler
- ✅ AI Prompt Generator
- ✅ Kontaktformular
- ✅ Video Portfolio

**Next Level:** Erweitere mit Social Media APIs und echter Automatisierung (siehe README.md)!

Happy Marketing! 🌟
